# MDO Lab sphinx theme
[![PyPI](https://img.shields.io/pypi/v/sphinx_mdolab_theme)](https://pypi.org/project/sphinx-mdolab-theme/)
[![Build Status](https://dev.azure.com/mdolab/Public/_apis/build/status/mdolab.sphinx_mdolab_theme?branchName=main)](https://dev.azure.com/mdolab/Public/_build/latest?definitionId=37&branchName=main)

This is the sphinx theme to be used by all MDO Lab documentation.
